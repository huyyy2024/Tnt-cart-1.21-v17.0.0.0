package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation — 2-tick Grim-safe pattern.
 *
 * tick N   → setPending(rot)
 * beforeSync (tick N) → applyBeforeSync() → movement packet carries rot
 * tick N+1 → interact → restoreAfterInteract()
 *
 * Fields used: headYaw, bodyYaw (confirmed in Yarn 1.21+build.9).
 * lastBodyYaw / lastHeadYaw do NOT exist in this mapping — not used.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static volatile float[] pendingRot = null;
    private static volatile float   savedYaw   = 0f;
    private static volatile float   savedPitch = 0f;
    private static volatile boolean hasPending = false;

    public static void setPending(ClientPlayerEntity player, float[] rot) {
        savedYaw   = player.getYaw();
        savedPitch = player.getPitch();
        pendingRot = rot;
        hasPending = true;
    }

    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (!hasPending || pendingRot == null) return false;
        applyRaw(player, pendingRot);
        return true;
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        if (player == null) return;
        boolean was = hasPending;
        hasPending = false;
        pendingRot = null;
        if (was) applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    public static boolean hasPendingRotation() { return hasPending; }

    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        Vec3d eyes = player.getEyePos();
        double dx   = target.x - eyes.x;
        double dy   = target.y - eyes.y;
        double dz   = target.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    private static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];   // Yarn 1.21+build.9 — confirmed
        player.bodyYaw = rot[0];   // Yarn 1.21+build.9 — confirmed
    }
}
